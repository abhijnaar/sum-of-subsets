"""Serves frontend/index.html on port 8000"""
import http.server
import socketserver
import os

PORT = 8000
DIR  = os.path.dirname(os.path.abspath(__file__))

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIR, **kwargs)
    def log_message(self, fmt, *args):
        print("[frontend] " + fmt % args)

if __name__ == "__main__":
    with socketserver.TCPServer(("", PORT), Handler) as s:
        print("Frontend running on http://localhost:8000")
        s.serve_forever()
