from http.server import HTTPServer, BaseHTTPRequestHandler
import json


# ──────────────────────────────────────────────────────────────
#  Backtracking Algorithm
# ──────────────────────────────────────────────────────────────

def sum_of_subsets(numbers, target):
    numbers_sorted = sorted(numbers)
    results = []
    steps = []
    call_count = [0]

    def backtrack(index, current, current_sum):
        call_count[0] += 1
        steps.append({
            "index": index,
            "current": list(current),
            "current_sum": current_sum,
            "action": "explore"
        })

        if current_sum == target:
            results.append(list(current))
            steps.append({
                "index": index,
                "current": list(current),
                "current_sum": current_sum,
                "action": "found"
            })
            return

        if index >= len(numbers_sorted) or current_sum > target:
            steps.append({
                "index": index,
                "current": list(current),
                "current_sum": current_sum,
                "action": "pruned"
            })
            return

        for i in range(index, len(numbers_sorted)):
            if i > index and numbers_sorted[i] == numbers_sorted[i - 1]:
                continue
            num = numbers_sorted[i]
            if current_sum + num > target:
                steps.append({
                    "index": i,
                    "current": list(current),
                    "current_sum": current_sum,
                    "action": "pruned",
                    "reason": "exceeds target"
                })
                break
            current.append(num)
            backtrack(i + 1, current, current_sum + num)
            current.pop()

    backtrack(0, [], 0)

    return {
        "numbers": numbers_sorted,
        "target": target,
        "subsets": results,
        "found": len(results) > 0,
        "count": len(results),
        "steps": steps,
        "calls": call_count[0]
    }


# ──────────────────────────────────────────────────────────────
#  HTTP Handler
# ──────────────────────────────────────────────────────────────

class Handler(BaseHTTPRequestHandler):

    def _send(self, status, body):
        data = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self._send(204, {})

    def do_GET(self):
        if self.path == "/health":
            self._send(200, {"status": "ok"})
        else:
            self._send(404, {"error": "Not found"})

    def do_POST(self):
        if self.path != "/solve":
            self._send(404, {"error": "Not found"})
            return

        length = int(self.headers.get("Content-Length", 0))
        try:
            payload = json.loads(self.rfile.read(length))
        except Exception:
            self._send(400, {"error": "Invalid JSON"})
            return

        numbers = payload.get("numbers", [])
        target  = payload.get("target")

        if not isinstance(numbers, list) or not numbers:
            self._send(400, {"error": "Provide a non-empty list of numbers."})
            return
        if not all(isinstance(n, (int, float)) for n in numbers):
            self._send(400, {"error": "All numbers must be numeric."})
            return
        if not isinstance(target, (int, float)):
            self._send(400, {"error": "Provide a numeric target."})
            return
        if len(numbers) > 20:
            self._send(400, {"error": "Maximum 20 numbers allowed."})
            return

        result = sum_of_subsets([int(n) for n in numbers], int(target))
        self._send(200, result)

    def log_message(self, fmt, *args):
        print("[backend] " + fmt % args)


# ──────────────────────────────────────────────────────────────
#  Entry Point
# ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    server = HTTPServer(("0.0.0.0", 5000), Handler)
    print("Backend running on http://localhost:5000")
    server.serve_forever()
