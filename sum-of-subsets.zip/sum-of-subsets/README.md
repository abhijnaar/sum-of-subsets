# Sum of Subsets — Backtracking Visualiser

## Project Structure

```
sum-of-subsets/
├── backend/
│   └── app.py          Python HTTP server + backtracking algorithm  (port 5000)
└── frontend/
    ├── index.html       Single-page visualiser UI
    └── serve.py         Static file server  (port 8000)
```

---

## How to Run (Windows PowerShell)

### Step 1 — Start the backend
Open a terminal and run:
```
cd sum-of-subsets\backend
python app.py
```
You should see: `Backend running on http://localhost:5000`

### Step 2 — Start the frontend
Open a SECOND terminal and run:
```
cd sum-of-subsets\frontend
python serve.py
```
You should see: `Frontend running on http://localhost:8000`

### Step 3 — Open the app
Go to: http://localhost:8000

---

## Algorithm

The `sum_of_subsets` function in `backend/app.py` uses **backtracking with pruning**:

1. Sort numbers ascending
2. Recursively try including each number
3. If `current_sum == target` → record the subset (FOUND)
4. If `current_sum > target` or index out of range → stop branch (PRUNED)
5. If `numbers[i] + current_sum > target` → break early (sorted, so all further will too)
6. Skip duplicates at the same recursion level

**Complexity:** O(2^n) worst case, pruning reduces average case significantly.

---

## API

### POST http://localhost:5000/solve
Request:
```json
{ "numbers": [3, 7, 1, 8, 2], "target": 10 }
```
Response:
```json
{
  "numbers": [1, 2, 3, 7, 8],
  "target": 10,
  "subsets": [[1,2,7],[2,8],[3,7]],
  "found": true,
  "count": 3,
  "steps": [...],
  "calls": 16
}
```

### GET http://localhost:5000/health
```json
{ "status": "ok" }
```

---

## Example

Input set: `{3, 7, 1, 8, 2}`, Target: `10`

Valid subsets found:
- `[1, 2, 7]` = 10 ✓
- `[2, 8]`    = 10 ✓
- `[3, 7]`    = 10 ✓
